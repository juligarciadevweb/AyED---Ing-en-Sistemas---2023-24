#include <stdio.h>
#include<stdlib.h>
#include<windows.h>
#include<string.h>

// Funci�n para mostrar cada palabra de la cadena en una fila nueva
void mostrarPalabras(char cadena[]) {
    for (int i = 0; cadena[i] != '\0'; i++) {
        if (cadena[i] == ',') {
            printf("\n");  // Cambio de l�nea al encontrar una coma
        } else {
            putchar(cadena[i]);
        }
    }
    printf("\n");
}

// Funci�n para calcular la longitud de la cadena sin usar strlen
int calcularLongitud(char cadena[]) {
    int longitud = 0;
    for (int i = 0; cadena[i] != '\0'; i++) {
        longitud++;
    }
    return longitud;
}

int main() {
    char cadena[101];  // Tama�o m�ximo de la cadena es 100 + 1 para el car�cter nulo
    printf("Ingrese la cadena de nombres separados por comas (m�ximo 100 caracteres):\n");
    fgets(cadena, sizeof(cadena), stdin);

    // Eliminar el car�cter de nueva l�nea al final si est� presente
    int len = calcularLongitud(cadena);
    if (len > 0 && cadena[len - 1] == '\n') {
        cadena[len - 1] = '\0';
    }

    printf("\nPalabras en la cadena:\n");
    mostrarPalabras(cadena);

    int longitud = calcularLongitud(cadena);
    printf("Longitud de la cadena: %d caracteres\n", longitud);

    return 0;
}

