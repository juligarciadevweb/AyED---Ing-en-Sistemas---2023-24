#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<windows.h>

void cargarVectores(char *carreras[], int cantAlumnos[]) {
  int i;

  // Solicitamos la cantidad de asignaturas
  printf("Ingrese la cantidad de asignaturas: ");
  scanf("%d", &cantAlumnos[0]);

  // Cargamos los nombres de las asignaturas
  for (i = 1; i <= cantAlumnos[0]; i++) {
    printf("Ingrese el nombre de la asignatura %d: ", i);
    scanf("%s", carreras[i]);
  }

  // Cargamos la cantidad de alumnos inscriptos en cada asignatura
  for (i = 1; i <= cantAlumnos[0]; i++) {
    printf("Ingrese la cantidad de alumnos inscriptos en la asignatura %s: ", carreras[i]);
    scanf("%d", &cantAlumnos[i]);
  }
}
int asignaturaConMasInscriptos(char *carreras[], int cantAlumnos[]) {
  int i, asignaturaConMasInscriptos = 0, cantAlumnosMax = 0;

  // Recorremos todos los alumnos inscriptos
  for (i = 1; i <= cantAlumnos[0]; i++) {
    // Si la cantidad de alumnos inscriptos en la asignatura actual es mayor que la cantidad m�xima registrada, actualizamos la informaci�n
    if (cantAlumnos[i] > cantAlumnosMax) {
      asignaturaConMasInscriptos = i;
      cantAlumnosMax = cantAlumnos[i];
    }
  }

  return asignaturaConMasInscriptos;
}
int main() {
  // Declaramos los vectores
  char *carreras[100];
  int cantAlumnos[100];

  // Cargamos los vectores
  cargarVectores(carreras, cantAlumnos);

  // Obtenemos la asignatura con m�s inscriptos
  int asignaturaConMasInscriptos = asignaturaConMasInscriptos(carreras, cantAlumnos);

  // Mostramos la informaci�n
  printf("La asignatura con m�s inscriptos es: %s\n", carreras[asignaturaConMasInscriptos]);
  printf("La cantidad de alumnos inscriptos es: %d\n", cantAlumnos[asignaturaConMasInscriptos]);

  return 0;
}
