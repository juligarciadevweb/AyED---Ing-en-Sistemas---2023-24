#include <stdio.h>
#include <string.h>

#define MAX_CARACTERES 120

// Funci�n para contar la cantidad de vocales en una cadena
int contarVocales(const char *cadena) {
    int contador = 0;
    for (int i = 0; cadena[i] != '\0'; i++) {
        char caracter = tolower(cadena[i]);  // Convertir a min�scula para simplificar la comparaci�n
        if (caracter == 'a' || caracter == 'e' || caracter == 'i' || caracter == 'o' || caracter == 'u') {
            contador++;
        }
    }
    return contador;
}

// Funci�n para mostrar el poema en pantalla
void mostrarPoema(const char *poema) {
    printf("Poema:\n%s\n", poema);
}

int main() {
    char poema[MAX_CARACTERES];

    printf("Escribe un poema (max 120 caracteres). Presiona Enter para finalizar:\n");
    fgets(poema, sizeof(poema), stdin);

    // Eliminar el salto de l�nea final si existe
    int longitud = strlen(poema);
    if (poema[longitud - 1] == '\n') {
        poema[longitud - 1] = '\0';
    }

    mostrarPoema(poema);

    int cantidadVocales = contarVocales(poema);
    printf("Cantidad de vocales (a, e, i, o, u): %d\n", cantidadVocales);

    return 0;
}

