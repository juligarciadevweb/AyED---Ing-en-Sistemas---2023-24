#include <stdio.h>
#include <string.h>

#define MAX_NOMBRES 10
#define MAX_CARACTERES 30

// Funci�n para ingresar los nombres de veh�culos
void ingresarNombres(char nombres[MAX_NOMBRES][MAX_CARACTERES], int cantidad) {
    printf("Ingresa los nombres de los veh�culos:\n");
    for (int i = 0; i < cantidad; i++) {
        printf("Nombre del veh�culo %d: ", i + 1);
        scanf("%s", nombres[i]);
    }
}

// Funci�n para convertir todos los nombres a may�sculas
void convertirAMayusculas(char nombres[MAX_NOMBRES][MAX_CARACTERES], int cantidad) {
    for (int i = 0; i < cantidad; i++) {
        for (int j = 0; nombres[i][j] != '\0'; j++) {
            if (nombres[i][j] >= 'a' && nombres[i][j] <= 'z') {
                // Si el caracter es una min�scula, lo convierte a may�scula restando 32 (la diferencia ASCII entre 'a' y 'A')
                nombres[i][j] -= 32;
            }
        }
    }
}

// Funci�n para copiar y ordenar los nombres de veh�culos
void copiarYOrdenarNombres(char nombres[MAX_NOMBRES][MAX_CARACTERES], int cantidad, char nombresOrdenados[MAX_NOMBRES][MAX_CARACTERES]) {
    // Copiar los nombres originales al nuevo vector
    for (int i = 0; i < cantidad; i++) {
        strcpy(nombresOrdenados[i], nombres[i]);
    }

    // Ordenar los nombres alfab�ticamente
    for (int i = 0; i < cantidad - 1; i++) {
        for (int j = i + 1; j < cantidad; j++) {
            if (strcmp(nombresOrdenados[i], nombresOrdenados[j]) > 0) {
                char temp[MAX_CARACTERES];
                strcpy(temp, nombresOrdenados[i]);
                strcpy(nombresOrdenados[i], nombresOrdenados[j]);
                strcpy(nombresOrdenados[j], temp);
            }
        }
    }
}

// Funci�n para mostrar los nombres ordenados
void mostrarNombresOrdenados(char nombres[MAX_NOMBRES][MAX_CARACTERES], int cantidad) {
    printf("Nombres de veh�culos ordenados alfab�ticamente:\n");
    for (int i = 0; i < cantidad; i++) {
        printf("%s\n", nombres[i]);
    }
}

// Funci�n para mostrar los nombres originales
void mostrarNombresOriginales(char nombres[MAX_NOMBRES][MAX_CARACTERES], int cantidad) {
    printf("Nombres de veh�culos originales:\n");
    for (int i = 0; i < cantidad; i++) {
        printf("%s\n", nombres[i]);
    }
}

int main() {
    char nombres[MAX_NOMBRES][MAX_CARACTERES];
    char nombresOrdenados[MAX_NOMBRES][MAX_CARACTERES];
    int cantidad = MAX_NOMBRES;

    ingresarNombres(nombres, cantidad);
    convertirAMayusculas(nombres, cantidad);
    copiarYOrdenarNombres(nombres, cantidad, nombresOrdenados);

    mostrarNombresOrdenados(nombresOrdenados, cantidad);
    mostrarNombresOriginales(nombres, cantidad);

    return 0;
}

