/**
 * Mostrar por pantalla los N primeros múltiplos de a y los M primeros múltiplos de b que sean
impares, siendo N, M, a y b datos de entradas siendo a y b mayores a 1.
 * 
*/

#include <stdio.h>

int main() {
    int N, M, a, b;
    printf("Ingrese el valor de N: ");
    scanf("%d", &N);
    printf("Ingrese el valor de M: ");
    scanf("%d", &M);
    printf("Ingrese el valor de a: ");
    scanf("%d", &a);
    printf("Ingrese el valor de b: ");
    scanf("%d", &b);

    printf("Los primeros %d múltiplos de %d:\n", N, a);
    for (int i = 1, count = 0; count < N; i++) {
        int multiple = i * a;
        if (multiple % 2 != 0) {
            printf("%d ", multiple);
            count++;
        }
    }

    printf("\n\nLos primeros %d múltiplos de %d que sean impares:\n", M, b);
    for (int i = 1, count = 0; count < M; i++) {
        int multiple = i * b;
        if (multiple % 2 != 0) {
            printf("%d ", multiple);
            count++;
        }
    }

    return 0;
}
