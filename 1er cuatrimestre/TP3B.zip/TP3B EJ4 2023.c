/*
Un banco registra el pago del servicio eléctrico de N usuarios. Entre los datos se registra: el
número de usuario, Periodo que se abona, consumo realizado en el periodo, Monto abonado.
Se desea saber:
a) Cuál es el monto final abonados por todos los usuarios.
b) Cuántos de estos usuarios son grandes contribuyentes. Se considera grandes contribuyentes a
los que tienen un consumo superior a 600 KWh.
Tener en cuenta que Según el consumo es el monto que se abona.
Consumo 1 (desde 1 hasta 200
KWh)
0.4935 $/KWh
Consumo 2 (desde 201 hasta 600
KWh)
0.5820 $/KWh
Consumo 3 (Superior a 600 KWh) 0.6150 $/KWh
*/
#include <stdio.h>

int main() {
    int n;
    printf("Ingrese la cantidad de usuarios: ");
    scanf("%d", &n);

    int numeroUsuario, periodo, consumo;
    float montoAbonado;
    float montoFinal = 0.0;
    int grandesContribuyentes = 0;

    int i = 0;
    while (i < n) {
        printf("Ingrese los datos del usuario %d:\n", i + 1);

        printf("Número de usuario: ");
        scanf("%d", &numeroUsuario);

        printf("Periodo que se abona: ");
        scanf("%d", &periodo);

        printf("Consumo realizado en el periodo (KWh): ");
        scanf("%d", &consumo);

        if (consumo > 600) {
            grandesContribuyentes++;
        }

        if (consumo <= 200) {
            montoAbonado = consumo * 0.4935;
        } else if (consumo <= 600) {
            montoAbonado = consumo * 0.5820;
        } else {
            montoAbonado = consumo * 0.6150;
        }

        montoFinal += montoAbonado;

        printf("Monto abonado: $%.2f\n", montoAbonado);
        printf("\n");

        i++;
    }

    printf("Resultados:\n");
    printf("a) Monto final abonado por todos los usuarios: $%.2f\n", montoFinal);
    printf("b) Cantidad de grandes contribuyentes: %d\n", grandesContribuyentes);

    return 0;
}


*/

#include <stdio.h>

int main() {
    int n;
    printf("Ingrese la cantidad de usuarios: ");
    scanf("%d", &n);

    int numeroUsuario, periodo, consumo;
    float montoAbonado;
    float montoFinal = 0.0;
    int grandesContribuyentes = 0;

    int i = 0;
    while (i < n) {
        printf("Ingrese los datos del usuario %d:\n", i + 1);

        printf("Número de usuario: ");
        scanf("%d", &numeroUsuario);

        printf("Periodo que se abona: ");
        scanf("%d", &periodo);

        printf("Consumo realizado en el periodo (KWh): ");
        scanf("%d", &consumo);

        if (consumo > 600) {
            grandesContribuyentes++;
        }

        if (consumo <= 200) {
            montoAbonado = consumo * 0.4935;
        } else if (consumo <= 600) {
            montoAbonado = consumo * 0.5820;
        } else {
            montoAbonado = consumo * 0.6150;
        }

        montoFinal += montoAbonado;

        printf("Monto abonado: $%.2f\n", montoAbonado);
        printf("\n");

        i++;
    }

    printf("Resultados:\n");
    printf("a) Monto final abonado por todos los usuarios: $%.2f\n", montoFinal);
    printf("b) Cantidad de grandes contribuyentes: %d\n", grandesContribuyentes);

    return 0;
}
