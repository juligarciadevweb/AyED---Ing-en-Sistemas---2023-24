/*
Ingresar N pares de valores de x e y correspondiente a las coordenadas de un punto en el
plano, y la función y = 3 * X + 5; determine cuantos de los puntos:
a. Están sobre la gráfica de la función.
b. Están por debajo de la función
*/
#include <stdio.h>

int main() 
{
    int n;
    int contadorSobreDebajo = 0;

    printf("Ingrese el número de puntos: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        float x, y;

        printf("Ingrese las coordenadas del punto %d (x y): ", i + 1);
        scanf("%f %f", &x, &y);

        if (y > (3 * x + 5)) {
            contadorSobreDebajo++;
        } else {
            contadorSobreDebajo--;
        }
    }

    int contadorSobre = (contadorSobreDebajo + n) / 2;
    int contadorDebajo = (n - contadorSobreDebajo) / 2;

    printf("Cantidad de puntos sobre la gráfica de la función: %d\n", contadorSobre);
    printf("Cantidad de puntos por debajo de la gráfica de la función: %d\n", contadorDebajo);

    return 0;
}

