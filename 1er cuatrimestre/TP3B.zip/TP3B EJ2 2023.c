/*
En un video club se administra los datos de los N socios: Edad, Deporte que realiza (1=Futbol,
2= Natación, 3 = jockey) y Sexo (1 = Masculinos, 2 = Femeninos).
Se desea saber:
a) Cuantos socios entre la edad de 30 y 50 años practican futbol.
b) Cuantos socios femeninos tiene el club y cuantos masculinos.
c) Cuantos socios son menores de 16 años.

*/

#include <stdio.h>

int main() {
    int nSocios, edad, deporte, sexo;
    int contadorFutbol = 0;
    int contadorFemeninos = 0;
    int contadorMasculinos = 0;
    int contadorMenores16 = 0;

    printf("Ingrese el número de socios: ");
    scanf("%d", &nSocios);

    int i = 0;
    while (i < nSocios) {
        printf("Socio %d:\n", i + 1);
        printf("Edad: ");
        scanf("%d", &edad);
        printf("Deporte que realiza (1=Fútbol, 2=Natación, 3=Jockey): ");
        scanf("%d", &deporte);
        printf("Sexo (1=Masculino, 2=Femenino): ");
        scanf("%d", &sexo);

        if (edad >= 30 && edad <= 50 && deporte == 1) {
            contadorFutbol++;
        }

        if (sexo == 1) {
            contadorMasculinos++;
        } else if (sexo == 2) {
            contadorFemeninos++;
        }

        if (edad < 16) {
            contadorMenores16++;
        }

        i++;
    }

    printf("a) Socios entre 30 y 50 años que practican fútbol: %d\n", contadorFutbol);
    printf("b) Cantidad de socios femeninos: %d\n", contadorFemeninos);
    printf("   Cantidad de socios masculinos: %d\n", contadorMasculinos);
    printf("c) Socios menores de 16 años son: %d",contadorMenores16);

    return 0;
}

