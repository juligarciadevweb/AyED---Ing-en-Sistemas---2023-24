/*
Realizar diagrama de flujo que permita saber la cantidad de números pares y la cantidad de
números impares que son ingresados por teclado. La entrada de números enteros debe repetirse
mientras sean diferente a cero.
*/

#include <stdio.h>

int main() {
    float calificacion;
    float promedio = 0.0;
    float mayorNota = 0.0;
    int cantidadNotas = 0;

    do {
        printf("Ingrese la calificación final (0 para finalizar): ");
        scanf("%f", &calificacion);

        if (calificacion != 0) {
            promedio += calificacion;
            cantidadNotas++;

            if (calificacion > mayorNota) {
                mayorNota = calificacion;
            }
        }
    } while (calificacion != 0);

    if (cantidadNotas > 0) {
        promedio /= cantidadNotas;
        printf("Promedio de las notas ingresadas: %.2f\n", promedio);
        printf("Mayor nota obtenida: %.2f\n", mayorNota);
    } else {
        printf("No se ingresaron calificaciones\n");
    }

    return 0;
}
