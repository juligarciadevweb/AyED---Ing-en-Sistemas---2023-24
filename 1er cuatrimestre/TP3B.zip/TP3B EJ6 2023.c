#include <stdio.h>

int main() 
{
    int num;
    int sumaImpares = 0;

    printf("Ingrese un número (ingrese -1 para terminar): ");
    scanf("%d", &num);

    while (num != -1) 
    {
        if (num % 2 != 0) 
            {
                sumaImpares += num;
            }

        printf("Ingrese un número (ingrese -1 para terminar): ");
        scanf("%d", &num);
    }

    printf("La suma de los valores impares es: %d\n", sumaImpares);
    return 0;
}
