/*En un Hospital se realiza una investigación para determinar las patologías respiratorias en
época invernal. A tal efecto se cargan los siguientes datos de N voluntarios:
✓ EDAD
✓ SEXO (1 = Masculino, 2= Femenino).
✓ PATOLOGÍA (0 = Gripe Estacional, 1 = Gripe A, 2 = Neumonía, 3 = Bronquitis).
Se desea conocer:
a. La cantidad de personas de sexo masculino mayores a 58 años que padecen
Bronquitis o Gripe A.
b. La cantidad de personas de sexo femenino y masculino que padecen Gripe Estacional*/
#include <stdio.h>

int main() {
    int n;
    int contadorMasculinoMayores = 0;
    int contadorFemeninoGripeEstacional = 0;
    int contadorMasculinoGripeEstacional = 0;

    printf("Ingrese el número de voluntarios: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        int edad, sexo, patologia;

        printf("Ingrese la edad del voluntario %d: ", i + 1);
        scanf("%d", &edad);
        printf("Ingrese el sexo del voluntario %d (1 = Masculino, 2 = Femenino): ", i + 1);
        scanf("%d", &sexo);
        printf("Ingrese la patología del voluntario %d (0 = Gripe Estacional, 1 = Gripe A, 2 = Neumonía, 3 = Bronquitis): ", i + 1);
        scanf("%d", &patologia);

        if (sexo == 1 && edad > 58 && (patologia == 1 || patologia == 3)) {
            contadorMasculinoMayores++;
        }

        if (sexo == 2 && patologia == 0) {
            contadorFemeninoGripeEstacional++;
        }

        if (sexo == 1 && patologia == 0) {
            contadorMasculinoGripeEstacional++;
        }
    }

    printf("Cantidad de personas de sexo masculino mayores a 58 años que padecen Bronquitis o Gripe A: %d\n", contadorMasculinoMayores);
    printf("Cantidad de personas de sexo femenino que padecen Gripe Estacional: %d\n", contadorFemeninoGripeEstacional);
    printf("Cantidad de personas de sexo masculino que padecen Gripe Estacional: %d\n", contadorMasculinoGripeEstacional);

    return 0;
}
